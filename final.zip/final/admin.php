
<!DOCTYPE html>
<html>
    <head>
        <?php include('header.php') ?>
       
        <?php 
        session_start();
        if(isset($_SESSION['login_id'])){
            header('Location:home.php');
        }
        ?>
        <title>hello</title>
    </head>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
    <body>
        <div class="container">
        <div class="login-form">
                <h2><center><span></span><p>ONLINE EXAM MONITORING SYSTEM USING<br>FACIAL RECOGNITION</p></h2>
        </center>
      
        <center> <b>Please Login!</b>
        <hr></center>

        </div>
            <div class="card-body">
                     <form id="login-frm">
                        <div class="form-group">
       <b>Username:</b> <input type="text" name="username" class="form-control" required>
        <div style="height: 10px;"></div>   

        <b>Password:</b> <input type="password" name="password" class="form-control" required> 
        <div style="height: 15px;"></div>

        <button type="submit" class="btn btn-primary" name="login"><span></span> Login</button> <p></p> 
        </form>
        
            </div>
        
    </div>
    </div>
                        
                    </form>
            </div>
        </div>

        </body>
                

        <script>
            $(document).ready(function(){
                $('#login-frm').submit(function(e){
                    e.preventDefault()
                    $('#login-frm button').attr('disable',true)
                    $('#login-frm button').html('Please wait...')

                    $.ajax({
                        url:'./login_auth.php',
                        method:'POST',
                        data:$(this).serialize(),
                        error:err=>{
                            console.log(err)
                            alert('An error occured');
                            $('#login-frm button').removeAttr('disable')
                            $('#login-frm button').html('Login')
                        },
                        success:function(resp){
                            if(resp == 1){
                                location.replace('home.php')
                            }else{
                                alert("Incorrect username or password.")
                                $('#login-frm button').removeAttr('disable')
                                $('#login-frm button').html('Login')
                            }
                        }
                    })

                })
            })
        </script>


</html>