-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 25, 2021 at 02:44 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fakedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `exam_id` int(30) NOT NULL,
  `question_id` int(30) NOT NULL,
  `option_id` int(30) NOT NULL,
  `is_right` tinyint(1) NOT NULL COMMENT ' 1 = right, 0 = wrong',
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `user_id`, `exam_id`, `question_id`, `option_id`, `is_right`, `date_updated`) VALUES
(1, 7, 3, 3, 20, 0, '2021-04-18 15:40:07'),
(2, 7, 3, 4, 21, 0, '2021-04-18 15:40:07'),
(3, 7, 4, 5, 25, 0, '2021-04-18 19:20:56'),
(4, 7, 4, 7, 35, 0, '2021-04-18 19:20:56'),
(5, 6, 1, 1, 12, 0, '2021-04-18 19:28:11'),
(6, 6, 1, 2, 14, 0, '2021-04-18 19:28:11'),
(7, 3, 6, 10, 51, 0, '2021-04-18 19:32:05'),
(8, 3, 6, 12, 59, 0, '2021-04-18 19:32:05'),
(9, 3, 4, 5, 28, 0, '2021-04-18 19:32:20'),
(10, 3, 4, 7, 35, 0, '2021-04-18 19:32:20'),
(11, 4, 7, 13, 64, 0, '2021-04-18 19:34:45'),
(12, 4, 7, 14, 68, 0, '2021-04-18 19:34:45'),
(13, 4, 4, 5, 26, 0, '2021-04-18 19:35:13'),
(14, 4, 4, 7, 35, 0, '2021-04-18 19:35:13'),
(15, 10, 8, 15, 87, 0, '2021-04-19 06:53:07'),
(16, 10, 8, 16, 89, 0, '2021-04-19 06:53:07'),
(17, 10, 1, 8, 96, 0, '2021-04-19 07:00:22'),
(18, 10, 1, 9, 97, 0, '2021-04-19 07:00:22'),
(19, 9, 9, 17, 102, 0, '2021-04-19 07:03:51'),
(20, 9, 9, 18, 109, 1, '2021-04-19 07:03:51'),
(21, 12, 11, 19, 114, 0, '2021-04-19 07:32:03'),
(22, 12, 11, 20, 124, 0, '2021-04-19 07:32:03'),
(23, 9, 12, 21, 125, 1, '2021-04-19 14:29:35'),
(24, 9, 12, 22, 136, 0, '2021-04-19 14:29:35'),
(25, 12, 10, 24, 141, 1, '2021-04-19 15:07:10'),
(26, 12, 10, 25, 147, 0, '2021-04-19 15:07:10'),
(27, 7, 5, 26, 152, 0, '2021-04-19 15:23:24'),
(28, 7, 5, 27, 157, 1, '2021-04-19 15:23:24'),
(29, 12, 13, 28, 161, 0, '2021-04-19 16:01:47'),
(30, 12, 13, 29, 171, 0, '2021-04-19 16:01:47'),
(31, 12, 13, 30, 176, 0, '2021-04-19 16:01:47'),
(32, 6, 13, 28, 163, 0, '2021-04-19 16:05:08'),
(33, 6, 13, 29, 169, 0, '2021-04-19 16:05:08'),
(34, 6, 13, 30, 176, 0, '2021-04-19 16:05:08'),
(35, 6, 13, 31, 180, 0, '2021-04-19 16:05:08'),
(36, 3, 13, 28, 163, 0, '2021-04-19 16:06:26'),
(37, 3, 13, 29, 172, 0, '2021-04-19 16:06:26'),
(38, 3, 13, 30, 173, 0, '2021-04-19 16:06:26'),
(39, 3, 13, 31, 180, 0, '2021-04-19 16:06:26'),
(40, 6, 6, 10, 51, 0, '2021-04-19 20:23:11'),
(41, 6, 6, 12, 58, 0, '2021-04-19 20:23:11');

-- --------------------------------------------------------

--
-- Table structure for table `exam_list`
--

CREATE TABLE `exam_list` (
  `id` int(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `qpoints` int(11) NOT NULL DEFAULT 1,
  `user_id` int(20) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam_list`
--

INSERT INTO `exam_list` (`id`, `title`, `qpoints`, `user_id`, `date_updated`) VALUES
(1, 'AI', 4, 8, '2021-04-18 19:23:48'),
(2, 'mobile programming', 4, 2, '2021-04-18 19:23:59'),
(5, 'web', 4, 13, '2021-04-19 15:22:03'),
(6, 'graph theory', 3, 2, '2021-04-19 15:30:40'),
(8, 'operating systems', 3, 5, '2021-04-19 15:31:31'),
(9, 'data structures', 4, 13, '2021-04-19 15:30:25'),
(12, 'OOAD', 1, 11, '2021-04-19 15:59:38'),
(13, 'research methods', 3, 11, '2021-04-19 15:42:26');

-- --------------------------------------------------------

--
-- Table structure for table `exam_student_list`
--

CREATE TABLE `exam_student_list` (
  `id` int(30) NOT NULL,
  `exam_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam_student_list`
--

INSERT INTO `exam_student_list` (`id`, `exam_id`, `user_id`, `date_updated`) VALUES
(1, 3, 7, '2021-04-18 15:39:21'),
(2, 3, 3, '2021-04-18 15:39:21'),
(3, 3, 4, '2021-04-18 15:39:21'),
(4, 4, 7, '2021-04-18 19:17:17'),
(5, 4, 3, '2021-04-18 19:17:17'),
(6, 4, 4, '2021-04-18 19:17:17'),
(7, 1, 6, '2021-04-18 19:27:29'),
(8, 6, 6, '2021-04-18 19:31:40'),
(9, 6, 3, '2021-04-18 19:31:40'),
(10, 7, 4, '2021-04-18 19:33:28'),
(11, 8, 9, '2021-04-19 06:52:31'),
(12, 8, 10, '2021-04-19 06:52:31'),
(13, 1, 10, '2021-04-19 06:59:28'),
(14, 9, 9, '2021-04-19 07:03:20'),
(15, 11, 12, '2021-04-19 07:31:36'),
(16, 12, 9, '2021-04-19 14:28:56'),
(18, 10, 12, '2021-04-19 15:05:09'),
(19, 5, 7, '2021-04-19 15:22:49'),
(21, 13, 12, '2021-04-19 16:01:16'),
(22, 13, 6, '2021-04-19 16:04:45'),
(23, 13, 3, '2021-04-19 16:06:02');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(30) NOT NULL,
  `exam_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `score` int(5) NOT NULL,
  `total_score` int(5) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `exam_id`, `user_id`, `score`, `total_score`, `date_updated`) VALUES
(1, 3, 7, 0, 8, '2021-04-18 15:40:07'),
(2, 4, 7, 0, 8, '2021-04-18 19:20:57'),
(3, 1, 6, 0, 8, '2021-04-18 19:28:11'),
(4, 6, 3, 0, 6, '2021-04-18 19:32:05'),
(5, 4, 3, 0, 8, '2021-04-18 19:32:20'),
(6, 7, 4, 0, 8, '2021-04-18 19:34:45'),
(7, 4, 4, 0, 8, '2021-04-18 19:35:13'),
(8, 8, 10, 0, 6, '2021-04-19 06:53:07'),
(9, 1, 10, 0, 8, '2021-04-19 07:00:22'),
(10, 9, 9, 4, 8, '2021-04-19 07:03:51'),
(11, 11, 12, 0, 8, '2021-04-19 07:32:03'),
(12, 12, 9, 2, 4, '2021-04-19 14:29:35'),
(13, 10, 12, 4, 8, '2021-04-19 15:07:10'),
(14, 5, 7, 4, 8, '2021-04-19 15:23:24'),
(15, 13, 12, 0, 9, '2021-04-19 16:01:47'),
(16, 13, 6, 0, 12, '2021-04-19 16:05:08'),
(17, 13, 3, 0, 12, '2021-04-19 16:06:26'),
(18, 6, 6, 0, 6, '2021-04-19 20:23:11');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `user_id`, `subject`, `date_updated`) VALUES
(1, 5, 'AI', '2021-04-18 15:14:56'),
(2, 8, 'OOP 1', '2021-04-18 14:55:42'),
(3, 11, 'OOP 2', '2021-04-19 07:16:10'),
(4, 13, 'OOAD', '2021-04-19 14:27:17');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(30) NOT NULL,
  `question` text NOT NULL,
  `qid` int(30) NOT NULL,
  `order_by` int(11) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `qid`, `order_by`, `date_updated`) VALUES
(8, '0uygiuyfuyfgfjhg', 1, 0, '2021-04-19 06:59:40'),
(9, 'ghghghgkjl.oiuhhfgfhv', 1, 0, '2021-04-19 06:59:54'),
(10, '0', 6, 0, '2021-04-18 19:31:06'),
(12, '0', 6, 0, '2021-04-18 19:31:24'),
(15, '7808900', 8, 0, '2021-04-19 06:52:03'),
(16, '0', 8, 0, '2021-04-19 06:51:18'),
(17, 'DFS', 9, 0, '2021-04-19 07:02:34'),
(18, 'BFS', 9, 0, '2021-04-19 07:03:12'),
(21, 'OOAD', 12, 0, '2021-04-19 14:28:27'),
(22, 'Omhgjhg', 12, 0, '2021-04-19 14:28:42'),
(23, 'khkhj', 1, 0, '2021-04-19 14:51:44'),
(26, 'ccc', 5, 0, '2021-04-19 15:22:27'),
(27, 'zxxxx', 5, 0, '2021-04-19 15:22:37'),
(28, 'qwqwq', 13, 0, '2021-04-19 15:42:50'),
(29, '3243434324234234', 13, 0, '2021-04-19 15:43:07'),
(30, 'wqwad', 13, 0, '2021-04-19 16:01:05'),
(31, 'bfgbfgbfgb', 13, 0, '2021-04-19 16:04:33');

-- --------------------------------------------------------

--
-- Table structure for table `question_opt`
--

CREATE TABLE `question_opt` (
  `id` int(30) NOT NULL,
  `option_txt` text NOT NULL,
  `question_id` int(30) NOT NULL,
  `is_right` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1= right answer',
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question_opt`
--

INSERT INTO `question_opt` (`id`, `option_txt`, `question_id`, `is_right`, `date_updated`) VALUES
(9, 'artificial insect', 1, 0, '2021-04-18 15:35:53'),
(10, 'artificial human', 1, 0, '2021-04-18 15:35:53'),
(11, 'artificial ink', 1, 0, '2021-04-18 15:35:53'),
(12, 'artificial inteligence', 1, 0, '2021-04-18 15:35:53'),
(13, 'artificial insect', 2, 1, '2021-04-18 15:36:37'),
(14, 'Please help Please', 2, 0, '2021-04-18 15:36:37'),
(15, 'artificial ink', 2, 0, '2021-04-18 15:36:37'),
(16, 'artificial inteligence', 2, 0, '2021-04-18 15:36:37'),
(21, 'sdfsd', 4, 0, '2021-04-18 15:39:05'),
(22, 'sdrfsd', 4, 0, '2021-04-18 15:39:06'),
(23, 'esres', 4, 0, '2021-04-18 15:39:06'),
(24, 'esrwe', 4, 0, '2021-04-18 15:39:06'),
(29, '1', 6, 0, '2021-04-18 19:16:39'),
(30, 'n', 6, 0, '2021-04-18 19:16:39'),
(31, 'nnnnnnnnnnnnnnnnnn', 6, 0, '2021-04-18 19:16:39'),
(32, 'nnnnnnnnnnnnnnnnnnnn', 6, 0, '2021-04-18 19:16:39'),
(33, '56', 7, 1, '2021-04-18 19:17:05'),
(34, '67', 7, 0, '2021-04-18 19:17:05'),
(35, '98', 7, 0, '2021-04-18 19:17:05'),
(36, '89', 7, 0, '2021-04-18 19:17:05'),
(49, 'ert', 10, 1, '2021-04-18 19:31:06'),
(50, 'dfgdf', 10, 0, '2021-04-18 19:31:06'),
(51, 'dfgdf', 10, 0, '2021-04-18 19:31:06'),
(52, 'rtfer', 10, 0, '2021-04-18 19:31:06'),
(53, 'ert', 11, 1, '2021-04-18 19:31:07'),
(54, 'dfgdf', 11, 0, '2021-04-18 19:31:07'),
(55, 'dfgdf', 11, 0, '2021-04-18 19:31:07'),
(56, 'rtfer', 11, 0, '2021-04-18 19:31:07'),
(57, '23', 12, 0, '2021-04-18 19:31:24'),
(58, '34', 12, 0, '2021-04-18 19:31:24'),
(59, '45', 12, 0, '2021-04-18 19:31:24'),
(60, '45', 12, 0, '2021-04-18 19:31:24'),
(65, '1', 14, 0, '2021-04-18 19:33:19'),
(66, '3', 14, 0, '2021-04-18 19:33:19'),
(67, '5', 14, 0, '2021-04-18 19:33:19'),
(68, '7', 14, 0, '2021-04-18 19:33:19'),
(85, '56', 15, 1, '2021-04-19 06:52:03'),
(86, '67', 15, 0, '2021-04-19 06:52:03'),
(87, '78', 15, 0, '2021-04-19 06:52:03'),
(88, '78', 15, 0, '2021-04-19 06:52:03'),
(89, '789', 16, 0, '2021-04-19 06:52:14'),
(90, 'ui', 16, 0, '2021-04-19 06:52:14'),
(91, '678', 16, 0, '2021-04-19 06:52:14'),
(92, '89', 16, 0, '2021-04-19 06:52:14'),
(93, '1', 8, 1, '2021-04-19 06:59:40'),
(94, '2', 8, 0, '2021-04-19 06:59:41'),
(95, '3', 8, 0, '2021-04-19 06:59:41'),
(96, '4', 8, 0, '2021-04-19 06:59:41'),
(97, '1', 9, 0, '2021-04-19 06:59:54'),
(98, '2', 9, 0, '2021-04-19 06:59:54'),
(99, '3', 9, 1, '2021-04-19 06:59:54'),
(100, '4', 9, 0, '2021-04-19 06:59:54'),
(101, 'depth first search', 17, 1, '2021-04-19 07:02:34'),
(102, 'irst search', 17, 0, '2021-04-19 07:02:34'),
(103, ' search', 17, 0, '2021-04-19 07:02:34'),
(104, 'rgfhgfh', 17, 0, '2021-04-19 07:02:34'),
(109, 'Bredth first search', 18, 1, '2021-04-19 07:03:12'),
(110, 'irst search', 18, 0, '2021-04-19 07:03:12'),
(111, ' search', 18, 0, '2021-04-19 07:03:12'),
(112, 'rgfhgfh', 18, 0, '2021-04-19 07:03:12'),
(121, 'ooop', 20, 0, '2021-04-19 07:31:28'),
(122, 'tfghftg', 20, 0, '2021-04-19 07:31:28'),
(123, 'rdgd', 20, 1, '2021-04-19 07:31:28'),
(124, 'sdfsdg', 20, 0, '2021-04-19 07:31:28'),
(125, 'OOAD', 21, 1, '2021-04-19 14:28:27'),
(126, 'we', 21, 0, '2021-04-19 14:28:27'),
(127, 'er', 21, 0, '2021-04-19 14:28:27'),
(128, 'gdf', 21, 0, '2021-04-19 14:28:27'),
(133, 'OOAD', 22, 0, '2021-04-19 14:28:42'),
(134, 'we', 22, 1, '2021-04-19 14:28:42'),
(135, 'er', 22, 0, '2021-04-19 14:28:42'),
(136, 'gdf', 22, 0, '2021-04-19 14:28:42'),
(137, 'uu', 23, 0, '2021-04-19 14:51:44'),
(138, 'hngh', 23, 0, '2021-04-19 14:51:44'),
(139, 'hgh', 23, 0, '2021-04-19 14:51:44'),
(140, 'yty', 23, 0, '2021-04-19 14:51:44'),
(145, 'aasasa', 25, 1, '2021-04-19 15:04:58'),
(146, 'fdffdsd', 25, 0, '2021-04-19 15:04:58'),
(147, 'sasa', 25, 0, '2021-04-19 15:04:58'),
(148, 'dfd', 25, 0, '2021-04-19 15:04:58'),
(149, 'aaa', 26, 1, '2021-04-19 15:22:27'),
(150, 'sss', 26, 0, '2021-04-19 15:22:27'),
(151, 'dddd', 26, 0, '2021-04-19 15:22:27'),
(152, 'fffff', 26, 0, '2021-04-19 15:22:27'),
(157, 'aaa', 27, 1, '2021-04-19 15:22:37'),
(158, 'sss', 27, 0, '2021-04-19 15:22:37'),
(159, 'dddd', 27, 0, '2021-04-19 15:22:37'),
(160, 'fffff', 27, 0, '2021-04-19 15:22:37'),
(161, 'erffd', 28, 0, '2021-04-19 15:42:50'),
(162, 'vffgbgb', 28, 0, '2021-04-19 15:42:50'),
(163, 'bgbdz', 28, 0, '2021-04-19 15:42:50'),
(164, 'asadsdbgfb', 28, 0, '2021-04-19 15:42:50'),
(169, 'erffd', 29, 0, '2021-04-19 15:43:07'),
(170, 'vffgbgb', 29, 0, '2021-04-19 15:43:07'),
(171, 'bgbdz', 29, 0, '2021-04-19 15:43:07'),
(172, 'asadsdbgfb', 29, 0, '2021-04-19 15:43:07'),
(173, 'ddff ', 30, 0, '2021-04-19 16:01:05'),
(174, 'vvvcx', 30, 0, '2021-04-19 16:01:05'),
(175, 'cxcxcc', 30, 0, '2021-04-19 16:01:05'),
(176, 'dfdfdfrws', 30, 0, '2021-04-19 16:01:05'),
(177, 'bfgbgf', 31, 0, '2021-04-19 16:04:33'),
(178, 'fgbg', 31, 0, '2021-04-19 16:04:33'),
(179, 'bfg', 31, 0, '2021-04-19 16:04:33'),
(180, 'fgdf', 31, 0, '2021-04-19 16:04:33');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `level_section` varchar(100) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `level_section`, `date_updated`) VALUES
(1, 6, 'Y2S2', '2021-04-18 14:52:16'),
(2, 7, 'Y3S1', '2021-04-18 14:54:09'),
(3, 9, 'Y3s2', '2021-04-19 06:48:19'),
(4, 10, 'Y2S2', '2021-04-19 06:48:56'),
(12, 20, 'Y2', '2021-06-09 16:52:15'),
(22, 30, 'Y2S2', '2021-06-25 15:29:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` varchar(150) NOT NULL,
  `user_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = admin, 2= lecturer , 3 = student',
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `image` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `user_type`, `username`, `password`, `image`, `status`, `date_updated`) VALUES
(1, 'administrator', 1, 'admin', '1234', '', 1, '2021-04-17 16:16:55'),
(2, 'isayas afewerki', 2, 'jsmith', 'jsmith', '', 1, '2021-04-17 19:15:04'),
(3, 'ali', 3, 'ali', 'ali', '', 1, '2021-04-17 19:23:00'),
(4, 'nahom mihreteab', 3, 'munga irma', 'munga', '', 1, '2021-04-18 12:23:22'),
(5, 'tony stark', 2, 'tony', 'tony', '', 1, '2021-04-18 14:37:37'),
(6, 'peter parker', 3, 'peter', 'peter', '', 1, '2021-04-18 14:38:37'),
(7, 'tchala', 3, 'tchala', 'tchala', '', 1, '2021-04-18 14:54:09'),
(8, 'steve rogers', 2, 'steve', 'steve', '', 1, '2021-04-18 15:14:29'),
(9, 'natasha', 3, 'natasha', 'natasha', '', 1, '2021-04-19 06:48:19'),
(10, 'wanda', 3, 'wanda', 'wanda', '', 1, '2021-04-19 06:48:56'),
(11, 'vision', 2, 'vision', 'vision', '', 1, '2021-04-19 07:16:10'),
(13, 'kidan', 2, 'kidan', 'kidan', '', 1, '2021-04-19 14:27:17'),
(20, 'Vip', 3, 'vip', 'boss', '', 1, '2021-06-09 16:52:14'),
(30, 'Chat', 3, 'chat', 'chat', 'upload/chat.JPG', 1, '2021-06-25 15:29:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_list`
--
ALTER TABLE `exam_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_student_list`
--
ALTER TABLE `exam_student_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_opt`
--
ALTER TABLE `question_opt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `exam_list`
--
ALTER TABLE `exam_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `exam_student_list`
--
ALTER TABLE `exam_student_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `question_opt`
--
ALTER TABLE `question_opt`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
