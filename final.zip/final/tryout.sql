-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2021 at 01:58 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tryout`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `exam_id` int(30) NOT NULL,
  `question_id` int(30) NOT NULL,
  `option_id` int(30) NOT NULL,
  `is_right` tinyint(1) NOT NULL COMMENT ' 1 = right, 0 = wrong',
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `user_id`, `exam_id`, `question_id`, `option_id`, `is_right`, `date_updated`) VALUES
(1, 7, 3, 3, 20, 0, '2021-04-18 15:40:07'),
(2, 7, 3, 4, 21, 0, '2021-04-18 15:40:07'),
(3, 7, 4, 5, 25, 0, '2021-04-18 19:20:56'),
(4, 7, 4, 7, 35, 0, '2021-04-18 19:20:56'),
(5, 6, 1, 1, 12, 0, '2021-04-18 19:28:11'),
(6, 6, 1, 2, 14, 0, '2021-04-18 19:28:11'),
(7, 3, 6, 10, 51, 0, '2021-04-18 19:32:05'),
(8, 3, 6, 12, 59, 0, '2021-04-18 19:32:05'),
(9, 3, 4, 5, 28, 0, '2021-04-18 19:32:20'),
(10, 3, 4, 7, 35, 0, '2021-04-18 19:32:20'),
(11, 4, 7, 13, 64, 0, '2021-04-18 19:34:45'),
(12, 4, 7, 14, 68, 0, '2021-04-18 19:34:45'),
(13, 4, 4, 5, 26, 0, '2021-04-18 19:35:13'),
(14, 4, 4, 7, 35, 0, '2021-04-18 19:35:13'),
(15, 10, 8, 15, 87, 0, '2021-04-19 06:53:07'),
(16, 10, 8, 16, 89, 0, '2021-04-19 06:53:07'),
(17, 10, 1, 8, 96, 0, '2021-04-19 07:00:22'),
(18, 10, 1, 9, 97, 0, '2021-04-19 07:00:22'),
(19, 9, 9, 17, 102, 0, '2021-04-19 07:03:51'),
(20, 9, 9, 18, 109, 1, '2021-04-19 07:03:51'),
(21, 12, 11, 19, 114, 0, '2021-04-19 07:32:03'),
(22, 12, 11, 20, 124, 0, '2021-04-19 07:32:03'),
(23, 9, 12, 21, 125, 1, '2021-04-19 14:29:35'),
(24, 9, 12, 22, 136, 0, '2021-04-19 14:29:35'),
(25, 12, 10, 24, 141, 1, '2021-04-19 15:07:10'),
(26, 12, 10, 25, 147, 0, '2021-04-19 15:07:10'),
(27, 7, 5, 26, 152, 0, '2021-04-19 15:23:24'),
(28, 7, 5, 27, 157, 1, '2021-04-19 15:23:24'),
(29, 12, 13, 28, 161, 0, '2021-04-19 16:01:47'),
(30, 12, 13, 29, 171, 0, '2021-04-19 16:01:47'),
(31, 12, 13, 30, 176, 0, '2021-04-19 16:01:47'),
(32, 6, 13, 28, 163, 0, '2021-04-19 16:05:08'),
(33, 6, 13, 29, 169, 0, '2021-04-19 16:05:08'),
(34, 6, 13, 30, 176, 0, '2021-04-19 16:05:08'),
(35, 6, 13, 31, 180, 0, '2021-04-19 16:05:08'),
(36, 3, 13, 28, 163, 0, '2021-04-19 16:06:26'),
(37, 3, 13, 29, 172, 0, '2021-04-19 16:06:26'),
(38, 3, 13, 30, 173, 0, '2021-04-19 16:06:26'),
(39, 3, 13, 31, 180, 0, '2021-04-19 16:06:26'),
(40, 6, 6, 10, 51, 0, '2021-04-19 20:23:11'),
(41, 6, 6, 12, 58, 0, '2021-04-19 20:23:11'),
(42, 34, 8, 15, 85, 1, '2021-05-08 10:44:48'),
(43, 34, 8, 16, 91, 0, '2021-05-08 10:44:48'),
(44, 35, 2, 32, 183, 0, '2021-05-28 13:32:11'),
(45, 35, 2, 33, 185, 1, '2021-05-28 13:32:12'),
(46, 10, 14, 34, 191, 0, '2021-05-29 12:54:27'),
(47, 10, 14, 36, 200, 0, '2021-05-29 12:54:27'),
(48, 7, 14, 34, 191, 0, '2021-05-29 12:55:42'),
(49, 7, 14, 36, 198, 0, '2021-05-29 12:55:42'),
(50, 34, 14, 34, 192, 0, '2021-05-29 12:56:06'),
(51, 34, 14, 36, 199, 0, '2021-05-29 12:56:06'),
(52, 33, 14, 34, 192, 0, '2021-06-12 14:14:06'),
(53, 33, 14, 36, 200, 0, '2021-06-12 14:14:06'),
(54, 33, 17, 39, 209, 1, '2021-06-12 14:19:23'),
(55, 33, 17, 41, 218, 0, '2021-06-12 14:19:24'),
(56, 7, 16, 37, 201, 1, '2021-06-12 23:37:13'),
(57, 7, 16, 38, 205, 1, '2021-06-12 23:37:13'),
(58, 3, 14, 34, 190, 0, '2021-06-24 02:15:18'),
(59, 3, 14, 36, 199, 0, '2021-06-24 02:15:18'),
(60, 24, 14, 34, 191, 0, '2021-06-24 11:57:19'),
(61, 24, 14, 36, 199, 0, '2021-06-24 11:57:19');

-- --------------------------------------------------------

--
-- Table structure for table `exam_list`
--

CREATE TABLE `exam_list` (
  `id` int(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `qpoints` int(11) NOT NULL DEFAULT 1,
  `user_id` int(20) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam_list`
--

INSERT INTO `exam_list` (`id`, `title`, `qpoints`, `user_id`, `date_updated`) VALUES
(14, 'mobile programming', 2, 11, '2021-05-29 16:22:43'),
(15, 'web design I', 3, 2, '2021-05-29 16:09:02'),
(16, 'sexual desire 1', 2, 0, '2021-06-05 12:28:22'),
(17, 'web design IV', 2, 0, '2021-06-12 14:17:13');

-- --------------------------------------------------------

--
-- Table structure for table `exam_student_list`
--

CREATE TABLE `exam_student_list` (
  `id` int(30) NOT NULL,
  `exam_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam_student_list`
--

INSERT INTO `exam_student_list` (`id`, `exam_id`, `user_id`, `date_updated`) VALUES
(1, 3, 7, '2021-04-18 15:39:21'),
(2, 3, 3, '2021-04-18 15:39:21'),
(3, 3, 4, '2021-04-18 15:39:21'),
(4, 4, 7, '2021-04-18 19:17:17'),
(5, 4, 3, '2021-04-18 19:17:17'),
(6, 4, 4, '2021-04-18 19:17:17'),
(7, 1, 6, '2021-04-18 19:27:29'),
(8, 6, 6, '2021-04-18 19:31:40'),
(9, 6, 3, '2021-04-18 19:31:40'),
(10, 7, 4, '2021-04-18 19:33:28'),
(11, 8, 9, '2021-04-19 06:52:31'),
(12, 8, 10, '2021-04-19 06:52:31'),
(13, 1, 10, '2021-04-19 06:59:28'),
(14, 9, 9, '2021-04-19 07:03:20'),
(15, 11, 12, '2021-04-19 07:31:36'),
(16, 12, 9, '2021-04-19 14:28:56'),
(18, 10, 12, '2021-04-19 15:05:09'),
(19, 5, 7, '2021-04-19 15:22:49'),
(21, 13, 12, '2021-04-19 16:01:16'),
(22, 13, 6, '2021-04-19 16:04:45'),
(23, 13, 3, '2021-04-19 16:06:02'),
(24, 8, 34, '2021-05-08 10:44:18'),
(25, 2, 35, '2021-05-28 13:31:12'),
(26, 14, 10, '2021-05-29 12:53:59'),
(27, 14, 7, '2021-05-29 12:55:21'),
(28, 14, 34, '2021-05-29 12:55:21'),
(29, 14, 3, '2021-06-11 15:33:59'),
(30, 14, 33, '2021-06-12 14:13:26'),
(31, 17, 33, '2021-06-12 14:18:51'),
(32, 16, 7, '2021-06-12 23:36:46'),
(34, 14, 10, '2021-06-24 02:24:05'),
(35, 14, 24, '2021-06-24 02:24:53');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(30) NOT NULL,
  `exam_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `score` int(5) NOT NULL,
  `total_score` int(5) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `exam_id`, `user_id`, `score`, `total_score`, `date_updated`) VALUES
(1, 3, 7, 0, 8, '2021-04-18 15:40:07'),
(2, 4, 7, 0, 8, '2021-04-18 19:20:57'),
(3, 1, 6, 0, 8, '2021-04-18 19:28:11'),
(4, 6, 3, 0, 6, '2021-04-18 19:32:05'),
(5, 4, 3, 0, 8, '2021-04-18 19:32:20'),
(6, 7, 4, 0, 8, '2021-04-18 19:34:45'),
(7, 4, 4, 0, 8, '2021-04-18 19:35:13'),
(8, 8, 10, 0, 6, '2021-04-19 06:53:07'),
(9, 1, 10, 0, 8, '2021-04-19 07:00:22'),
(10, 9, 9, 4, 8, '2021-04-19 07:03:51'),
(11, 11, 12, 0, 8, '2021-04-19 07:32:03'),
(12, 12, 9, 2, 4, '2021-04-19 14:29:35'),
(13, 10, 12, 4, 8, '2021-04-19 15:07:10'),
(14, 5, 7, 4, 8, '2021-04-19 15:23:24'),
(15, 13, 12, 0, 9, '2021-04-19 16:01:47'),
(16, 13, 6, 0, 12, '2021-04-19 16:05:08'),
(17, 13, 3, 0, 12, '2021-04-19 16:06:26'),
(18, 6, 6, 0, 6, '2021-04-19 20:23:11'),
(19, 8, 34, 3, 6, '2021-05-08 10:44:48'),
(20, 2, 35, 4, 8, '2021-05-28 13:32:12'),
(21, 14, 10, 0, 4, '2021-05-29 12:54:27'),
(22, 14, 7, 0, 4, '2021-05-29 12:55:42'),
(23, 14, 34, 0, 4, '2021-05-29 12:56:06'),
(24, 14, 33, 0, 4, '2021-06-12 14:14:06'),
(25, 17, 33, 2, 4, '2021-06-12 14:19:24'),
(26, 16, 7, 4, 4, '2021-06-12 23:37:13'),
(27, 14, 3, 0, 4, '2021-06-24 02:15:18'),
(28, 14, 24, 0, 4, '2021-06-24 11:57:19');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `user_id`, `subject`, `date_updated`) VALUES
(1, 5, 'AI', '2021-04-18 15:14:56'),
(2, 8, 'OOP 1', '2021-04-18 14:55:42'),
(3, 11, 'OOP 2', '2021-04-19 07:16:10'),
(4, 13, 'OOAD', '2021-04-19 14:27:17'),
(5, 30, 'OOP 1', '2021-04-28 11:46:11'),
(6, 36, 'sexual desire', '2021-06-05 12:27:37'),
(7, 43, 'web design IV', '2021-06-12 14:16:29');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(30) NOT NULL,
  `question` text NOT NULL,
  `qid` int(30) NOT NULL,
  `order_by` int(11) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `qid`, `order_by`, `date_updated`) VALUES
(34, 'MMP 1', 14, 0, '2021-05-29 12:53:15'),
(36, 'EHRTH', 14, 0, '2021-05-29 12:53:35'),
(37, 'what is sex', 16, 0, '2021-06-05 12:28:49'),
(38, 'what is sex', 16, 0, '2021-06-05 12:28:50'),
(39, 'what is web design', 17, 0, '2021-06-12 14:18:02'),
(41, 'php', 17, 0, '2021-06-12 14:18:38');

-- --------------------------------------------------------

--
-- Table structure for table `question_opt`
--

CREATE TABLE `question_opt` (
  `id` int(30) NOT NULL,
  `option_txt` text NOT NULL,
  `question_id` int(30) NOT NULL,
  `is_right` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1= right answer',
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question_opt`
--

INSERT INTO `question_opt` (`id`, `option_txt`, `question_id`, `is_right`, `date_updated`) VALUES
(9, 'artificial insect', 1, 0, '2021-04-18 15:35:53'),
(10, 'artificial human', 1, 0, '2021-04-18 15:35:53'),
(11, 'artificial ink', 1, 0, '2021-04-18 15:35:53'),
(12, 'artificial inteligence', 1, 0, '2021-04-18 15:35:53'),
(13, 'artificial insect', 2, 1, '2021-04-18 15:36:37'),
(14, 'Please help Please', 2, 0, '2021-04-18 15:36:37'),
(15, 'artificial ink', 2, 0, '2021-04-18 15:36:37'),
(16, 'artificial inteligence', 2, 0, '2021-04-18 15:36:37'),
(21, 'sdfsd', 4, 0, '2021-04-18 15:39:05'),
(22, 'sdrfsd', 4, 0, '2021-04-18 15:39:06'),
(23, 'esres', 4, 0, '2021-04-18 15:39:06'),
(24, 'esrwe', 4, 0, '2021-04-18 15:39:06'),
(29, '1', 6, 0, '2021-04-18 19:16:39'),
(30, 'n', 6, 0, '2021-04-18 19:16:39'),
(31, 'nnnnnnnnnnnnnnnnnn', 6, 0, '2021-04-18 19:16:39'),
(32, 'nnnnnnnnnnnnnnnnnnnn', 6, 0, '2021-04-18 19:16:39'),
(33, '56', 7, 1, '2021-04-18 19:17:05'),
(34, '67', 7, 0, '2021-04-18 19:17:05'),
(35, '98', 7, 0, '2021-04-18 19:17:05'),
(36, '89', 7, 0, '2021-04-18 19:17:05'),
(53, 'ert', 11, 1, '2021-04-18 19:31:07'),
(54, 'dfgdf', 11, 0, '2021-04-18 19:31:07'),
(55, 'dfgdf', 11, 0, '2021-04-18 19:31:07'),
(56, 'rtfer', 11, 0, '2021-04-18 19:31:07'),
(57, '23', 12, 0, '2021-04-18 19:31:24'),
(58, '34', 12, 0, '2021-04-18 19:31:24'),
(59, '45', 12, 0, '2021-04-18 19:31:24'),
(60, '45', 12, 0, '2021-04-18 19:31:24'),
(65, '1', 14, 0, '2021-04-18 19:33:19'),
(66, '3', 14, 0, '2021-04-18 19:33:19'),
(67, '5', 14, 0, '2021-04-18 19:33:19'),
(68, '7', 14, 0, '2021-04-18 19:33:19'),
(89, '789', 16, 0, '2021-04-19 06:52:14'),
(90, 'ui', 16, 0, '2021-04-19 06:52:14'),
(91, '678', 16, 0, '2021-04-19 06:52:14'),
(92, '89', 16, 0, '2021-04-19 06:52:14'),
(97, '1', 9, 0, '2021-04-19 06:59:54'),
(98, '2', 9, 0, '2021-04-19 06:59:54'),
(99, '3', 9, 1, '2021-04-19 06:59:54'),
(100, '4', 9, 0, '2021-04-19 06:59:54'),
(109, 'Bredth first search', 18, 1, '2021-04-19 07:03:12'),
(110, 'irst search', 18, 0, '2021-04-19 07:03:12'),
(111, ' search', 18, 0, '2021-04-19 07:03:12'),
(112, 'rgfhgfh', 18, 0, '2021-04-19 07:03:12'),
(121, 'ooop', 20, 0, '2021-04-19 07:31:28'),
(122, 'tfghftg', 20, 0, '2021-04-19 07:31:28'),
(123, 'rdgd', 20, 1, '2021-04-19 07:31:28'),
(124, 'sdfsdg', 20, 0, '2021-04-19 07:31:28'),
(133, 'OOAD', 22, 0, '2021-04-19 14:28:42'),
(134, 'we', 22, 1, '2021-04-19 14:28:42'),
(135, 'er', 22, 0, '2021-04-19 14:28:42'),
(136, 'gdf', 22, 0, '2021-04-19 14:28:42'),
(137, 'uu', 23, 0, '2021-04-19 14:51:44'),
(138, 'hngh', 23, 0, '2021-04-19 14:51:44'),
(139, 'hgh', 23, 0, '2021-04-19 14:51:44'),
(140, 'yty', 23, 0, '2021-04-19 14:51:44'),
(145, 'aasasa', 25, 1, '2021-04-19 15:04:58'),
(146, 'fdffdsd', 25, 0, '2021-04-19 15:04:58'),
(147, 'sasa', 25, 0, '2021-04-19 15:04:58'),
(148, 'dfd', 25, 0, '2021-04-19 15:04:58'),
(157, 'aaa', 27, 1, '2021-04-19 15:22:37'),
(158, 'sss', 27, 0, '2021-04-19 15:22:37'),
(159, 'dddd', 27, 0, '2021-04-19 15:22:37'),
(160, 'fffff', 27, 0, '2021-04-19 15:22:37'),
(169, 'erffd', 29, 0, '2021-04-19 15:43:07'),
(170, 'vffgbgb', 29, 0, '2021-04-19 15:43:07'),
(171, 'bgbdz', 29, 0, '2021-04-19 15:43:07'),
(172, 'asadsdbgfb', 29, 0, '2021-04-19 15:43:07'),
(173, 'ddff ', 30, 0, '2021-04-19 16:01:05'),
(174, 'vvvcx', 30, 0, '2021-04-19 16:01:05'),
(175, 'cxcxcc', 30, 0, '2021-04-19 16:01:05'),
(176, 'dfdfdfrws', 30, 0, '2021-04-19 16:01:05'),
(177, 'bfgbgf', 31, 0, '2021-04-19 16:04:33'),
(178, 'fgbg', 31, 0, '2021-04-19 16:04:33'),
(179, 'bfg', 31, 0, '2021-04-19 16:04:33'),
(180, 'fgdf', 31, 0, '2021-04-19 16:04:33'),
(185, 'eryetrtjh', 33, 1, '2021-05-28 13:31:28'),
(186, 'ertyr', 33, 0, '2021-05-28 13:31:28'),
(187, 'ertger', 33, 0, '2021-05-28 13:31:28'),
(188, 'erstger', 33, 0, '2021-05-28 13:31:28'),
(189, 'DFSG', 34, 0, '2021-05-29 12:53:15'),
(190, 'DRGDF', 34, 0, '2021-05-29 12:53:15'),
(191, 'DFGDF', 34, 0, '2021-05-29 12:53:15'),
(192, 'DGDF', 34, 0, '2021-05-29 12:53:15'),
(193, 'DFSG', 35, 0, '2021-05-29 12:53:18'),
(194, 'DRGDF', 35, 0, '2021-05-29 12:53:18'),
(195, 'DFGDF', 35, 0, '2021-05-29 12:53:18'),
(196, 'DGDF', 35, 0, '2021-05-29 12:53:18'),
(197, 'RG', 36, 0, '2021-05-29 12:53:35'),
(198, 'DFG', 36, 0, '2021-05-29 12:53:35'),
(199, 'DFG', 36, 0, '2021-05-29 12:53:35'),
(200, 'XCV', 36, 0, '2021-05-29 12:53:35'),
(201, 'betae betae', 37, 1, '2021-06-05 12:28:49'),
(202, 'dds', 37, 0, '2021-06-05 12:28:50'),
(203, 'dds', 37, 0, '2021-06-05 12:28:50'),
(204, 'sds', 37, 0, '2021-06-05 12:28:50'),
(205, 'betae betae', 38, 1, '2021-06-05 12:28:50'),
(206, 'dds', 38, 0, '2021-06-05 12:28:50'),
(207, 'dds', 38, 0, '2021-06-05 12:28:50'),
(208, 'sds', 38, 0, '2021-06-05 12:28:50'),
(209, 'web design', 39, 1, '2021-06-12 14:18:02'),
(210, 'web', 39, 0, '2021-06-12 14:18:02'),
(211, 'web', 39, 0, '2021-06-12 14:18:02'),
(212, 'web', 39, 0, '2021-06-12 14:18:02'),
(213, 'web design', 40, 1, '2021-06-12 14:18:08'),
(214, 'web', 40, 0, '2021-06-12 14:18:08'),
(215, 'web', 40, 0, '2021-06-12 14:18:08'),
(216, 'web', 40, 0, '2021-06-12 14:18:08'),
(217, 'laravel', 41, 1, '2021-06-12 14:18:38'),
(218, 'sfds', 41, 0, '2021-06-12 14:18:38'),
(219, 'sdfs', 41, 0, '2021-06-12 14:18:38'),
(220, 'dfsd', 41, 0, '2021-06-12 14:18:38');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `level_section` varchar(100) NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `level_section`, `date_updated`, `image`) VALUES
(1, 6, 'Y2S2', '2021-04-18 14:52:16', ''),
(2, 7, 'Y3S1', '2021-04-18 14:54:09', ''),
(3, 9, 'Y3s2', '2021-04-19 06:48:19', ''),
(4, 10, 'Y2S2', '2021-04-19 06:48:56', ''),
(12, 21, 'Y2S2', '2021-04-23 07:52:08', ''),
(13, 22, 'asdfsd', '2021-04-23 08:32:49', ''),
(14, 23, 'Y2S2', '2021-04-23 13:01:48', ''),
(15, 24, 'Y3s2', '2021-04-24 13:35:49', ''),
(17, 26, 'Y3s2', '2021-04-27 08:35:31', ''),
(18, 27, 'Y2S2', '2021-04-27 09:38:13', ''),
(19, 28, 'cv', '2021-04-27 09:38:45', ''),
(21, 31, 'Y2S2', '2021-04-28 11:47:58', ''),
(23, 33, 'Y2S2', '2021-05-03 13:03:27', ''),
(24, 34, 'Y2S2', '2021-05-08 10:43:24', ''),
(25, 35, 'Y3s2', '2021-05-28 13:30:48', ''),
(26, 37, 'Y2S2', '2021-06-06 13:23:10', ''),
(27, 38, 'qw', '2021-06-08 22:57:04', ''),
(30, 41, 'Y2S2', '2021-06-09 17:52:33', ''),
(31, 42, 'fila', '2021-06-09 18:34:54', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` varchar(150) NOT NULL,
  `user_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = admin, 2= lecturer , 3 = student',
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `user_type`, `username`, `password`, `status`, `date_updated`) VALUES
(1, 'administrator', 1, 'admin', '1234', 1, '2021-04-17 16:16:55'),
(2, 'isayas afewerki', 2, 'jsmith', 'jsmith', 1, '2021-04-17 19:15:04'),
(3, 'ali', 3, 'ali', 'ali', 1, '2021-04-17 19:23:00'),
(4, 'nahom mihreteab', 3, 'munga irma', 'munga', 1, '2021-04-18 12:23:22'),
(5, 'tony stark', 2, 'tony', 'tony', 1, '2021-04-18 14:37:37'),
(6, 'peter parker', 3, 'peter', 'peter', 1, '2021-04-18 14:38:37'),
(7, 'tchala', 3, 'tchala', 'tchala', 1, '2021-04-18 14:54:09'),
(8, 'steve rogers', 2, 'steve', 'steve', 1, '2021-04-18 15:14:29'),
(9, 'natasha', 3, 'natasha', 'natasha', 1, '2021-04-19 06:48:19'),
(10, 'wanda', 3, 'wanda', 'wanda', 1, '2021-04-19 06:48:56'),
(11, 'vision', 2, 'vision', 'vision', 1, '2021-04-19 07:16:10'),
(13, 'kidan', 2, 'kidan', 'kidan', 1, '2021-04-19 14:27:17'),
(20, 'hello', 3, 'ton', 'hgvh', 1, '2021-04-23 07:51:29'),
(21, 'hello', 3, 'visio', 'tfyrtdy', 1, '2021-04-23 07:52:08'),
(22, 'afcsd', 3, 'sdfsd', 'weafwes', 1, '2021-04-23 08:32:49'),
(23, 'denice', 3, 'denice', 'denice', 1, '2021-04-23 13:01:48'),
(24, 'adam', 3, 'adam', 'adam', 1, '2021-04-24 13:35:48'),
(26, 'date_updated', 3, 'lop', 'lop', 1, '2021-04-27 08:35:31'),
(27, 'date_updated', 3, 'munga.irma', '.xxcx', 1, '2021-04-27 09:38:13'),
(28, 'sv', 3, 'cv', 'cv', 1, '2021-04-27 09:38:45'),
(30, 'ajok', 2, 'erer', 'erer', 1, '2021-04-28 11:46:10'),
(31, 'bro', 3, 'to', 'yo', 1, '2021-04-28 11:47:58'),
(33, 'dunia', 3, 'dunia', 'dunia', 1, '2021-05-03 13:03:27'),
(34, 'filli', 3, 'filli', 'filli', 1, '2021-05-08 10:43:24'),
(35, 'fasika', 3, 'fasika', 'fasika', 1, '2021-05-28 13:30:48'),
(36, 'jackson', 2, 'jackson', 'jackson', 1, '2021-06-05 12:27:37'),
(37, 'seb', 3, 'seb', 'seb', 1, '2021-06-06 13:23:10'),
(38, 'qw', 3, 'qw', 'qw', 1, '2021-06-08 22:57:03'),
(41, 'aron', 3, 'aron', 'aron', 1, '2021-06-09 17:52:33'),
(42, 'fila', 3, 'fila ', 'fila', 1, '2021-06-09 18:34:54'),
(43, 'Mr.watiti', 2, 'kenneth', 'kenneth', 1, '2021-06-12 14:16:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_list`
--
ALTER TABLE `exam_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_student_list`
--
ALTER TABLE `exam_student_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_opt`
--
ALTER TABLE `question_opt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `exam_list`
--
ALTER TABLE `exam_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `exam_student_list`
--
ALTER TABLE `exam_student_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `question_opt`
--
ALTER TABLE `question_opt`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
