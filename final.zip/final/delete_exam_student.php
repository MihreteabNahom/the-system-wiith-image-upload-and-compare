<?php 
include 'db_connect.php';
extract($_GET);
$delete = $conn->query("DELETE FROM exam_student_list where  id=".$qid);
if($delete)
	echo true;
?>